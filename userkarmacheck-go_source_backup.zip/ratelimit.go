// Package main — token-bucket rate limiter (restored 2026-11-09).
//
// The file had been emptied at some point mid-refactor, which broke the
// build; the semantics below match the original Task 2 design and the
// engine_test.go expectations:
//   - rate is given in requests PER MINUTE (the CLI convention), refilled
//     continuously at rate/60 tokens per second;
//   - the first `burst` requests are instant, anything above paces;
//   - Wait is ctx-cancellable (TestTokenBucketCancel: a 60s-away token
//     returns the ctx error instead of sleeping blind).
package main

import (
	"context"
	"sync"
	"time"
)

// TokenBucket paces requests: continuous refill, no timer goroutines.
// Every method is safe for concurrent use (150 workers share one IP bucket).
type TokenBucket struct {
	mu     sync.Mutex
	perSec float64 // refill rate (tokens per second)
	burst  float64
	tokens float64
	last   time.Time
}

// NewTokenBucket creates a bucket. perMin = requests per minute,
// burst = how many requests may pass instantly before pacing starts.
func NewTokenBucket(perMin float64, burst int) *TokenBucket {
	if perMin <= 0 {
		perMin = 60
	}
	if burst <= 0 {
		burst = 1
	}
	return &TokenBucket{
		perSec: perMin / 60,
		burst:  float64(burst),
		tokens: float64(burst),
		last:   time.Now(),
	}
}

// waitTime returns how long the caller must wait for the next token and
// refills the bucket up to "now" (caller holds the lock).
func (b *TokenBucket) now() {
	t := time.Now()
	if b.tokens < b.burst {
		b.tokens += t.Sub(b.last).Seconds() * b.perSec
		if b.tokens > b.burst {
			b.tokens = b.burst
		}
	}
	b.last = t
}

// Wait consumes one token, blocking (ctx-cancellable) until one is available.
func (b *TokenBucket) Wait(ctx context.Context) error {
	for {
		b.mu.Lock()
		b.now()
		if b.tokens >= 1 {
			b.tokens--
			b.mu.Unlock()
			return nil
		}
		deficit := 1 - b.tokens
		wait := time.Duration(deficit / b.perSec * float64(time.Second))
		b.mu.Unlock()
		// add a tiny epsilon so a freshly-refillable token is not missed
		if wait < 0 {
			wait = 0
		}
		if wait > 100*time.Millisecond {
			wait = 100 * time.Millisecond
		}
		timer := time.NewTimer(wait)
		select {
		case <-ctx.Done():
			timer.Stop()
			return ctx.Err()
		case <-timer.C:
		}
		b.mu.Lock()
		b.now()
		ready := b.tokens >= 1
		b.mu.Unlock()
		if ready {
			continue // re-check under the lock (races between waiters)
		}
	}
}

// TryWait takes a token if one is available right now (non blocking).
func (b *TokenBucket) TryWait() bool {
	b.mu.Lock()
	defer b.mu.Unlock()
	b.now()
	if b.tokens >= 1 {
		b.tokens -= 1
		return true
	}
	return false
}

// SetRate changes the refill rate (requests per minute). AIMD uses this.
func (b *TokenBucket) SetRate(perMin float64) {
	if perMin <= 0 {
		perMin = 1 // never allow a zero/negative rate: it would stall forever
	}
	b.mu.Lock()
	defer b.mu.Unlock()
	b.now()
	b.perSec = perMin / 60
	if b.burst > b.perSec*2 && b.perSec*2 >= 1 {
		// keep the burst proportional to a fast rate, but never below 1
		b.burst = b.perSec * 2
	}
}

// Rate returns the current rate in requests per minute.
func (b *TokenBucket) Rate() float64 {
	b.mu.Lock()
	defer b.mu.Unlock()
	return b.perSec * 60
}
