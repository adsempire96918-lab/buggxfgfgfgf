# userkarmacheck-go — Native Go Reddit Karma Checker

Python project (`userkarmacheck`) এর **সম্পূর্ণ native Go rewrite** — একই কাজ, একই output
format, কিন্তু অনেক দ্রুত ও শক্তিশালী (uTLS, goroutines, per-IP rate limiting, real Chrome login).

---

## বাংলায়

**কী করে?** `input.txt`-এ থাকা Reddit username (optional `:password`) চেক করে karma অনুযায়ী
আলাদা ফাইলে save করে।

> **ডেভেলপার হলে শুরু করুন `EXECUTION_PLAN.md` থেকে** — সব পরিবর্তনের task list, file scope,
> acceptance criteria আর loop-breaker সেখানে আছে।

**দরকার:** Go 1.22+ (build করতে), Google Chrome (login করতে)।

### দ্রুত শুরু (২ ধাপ)

1. **Install (একবার):** `install.bat` double-click করুন → Go দিয়ে `userkarmacheck.exe`
   build হবে। (Go 1.22+ লাগবে: https://go.dev/dl/)
2. **Run:** `run.bat` double-click করুন → `input.txt`-এর সব username চেক হবে →
   `full_out\` ফোল্ডারে result + `run_report.txt` সেভ হবে।

```
install.bat   ->  build the exe (run once)
run.bat       ->  run the checker
```

`run.bat` বান্ডেল করে আছে: `run.bat` (fast run), `run.bat --quiet` (no live panel),
`run.bat --help` (all flags), `run.bat login` (browser login / save a session),
`run.bat sessions` (validate the session folder), `run.bat <flags...>` (custom run).

> NSFW/mature প্রোফাইল দেখতে `sassion\` ফোল্ডারের session লাগে — এগুলো ইতিমধ্যে আছে
> (5561টি, প্রতিটি account-এর একটি করে Netscape cookie file)। নতুন session যোগ করতে
> `run.bat login` ব্যবহার করুন — ফোল্ডারে ফাইল ফেলে দিলেই checker নিজে থেকেই নিয়ে নেয়।

### Output ফাইল (Python project-এর হুবহু same)

| ফাইল | কী আছে |
|---|---|
| `0to500.txt` … `3000ormore.txt` | karma অনুযায়ী hit হওয়া username (raw input line) |
| `not_found.txt` | `user \| NOT_FOUND` |
| `banned.txt` | `user \| SUSPENDED` |
| `errors.txt` | `user \| ERROR: <error>` |
| `run_report.txt` | **run report**: total / valid / invalid / failed / speed / buckets |
| `session_usage.txt` | কোন session কোন user সার্ভ করেছে + VPN rotation log |

**Resume:** যেসব username আগে save হয়েছে সেগুলো আর চেক হয় না (progress থেকে চালিয়ে যান)।

### Flags (Python-এর হুবহু same)

```
-i, --input <file>        input list (default: input.txt)
-o, --output <dir>        output folder (default: current folder)
--threads <n>             concurrent workers (default 4)
--proxies <file>          proxy list: host:port[:user:pass] (একটা per line)
--cookies <file>          cookie file (default cookies.json)
--cookie-string <raw>     raw "Cookie:" header
--mode <auto|json|html>   auto = cookie/OAuth হলে JSON, না হলে HTML scrape
--token <raw>             Reddit OAuth access token
--client-id / --client-secret   Reddit app (OAuth app-only token)
--delay <sec>             প্রতি user-এর পরে delay (default 0.4)
--rate <permin>           প্রতি মিনিটে request (default 90; 0 = unlimited)
--timeout <sec>           request timeout (default 30)
--retries <n>             retry সংখ্যা (default 3)
--max-blocked <n>         এর বেশি blocked হলে run থামবে (default 10)
--no-preflight            startup auth check বাদ
--no-resume               আগে check করা username আবার check করবে
```

### Multi-session mode (NSFW + max speed) ⭐

`sassion/` folder-এর cookie session files দিয়ে চালু — প্রতিটি session একটি account,
আর প্রতিটি account-এর নিজস্ব rate budget আছে (measured ceiling ≈ **1.1 req/s**):

```bat
REM ⭐⭐ FASTEST — measured 1184 users/min, 0 errors (466 sessions)
run.bat --sessions sassion --lanes 466 --threads 150 ^
         --rate-per-ip 1200 --rate-per-session 72 --warmup 40 ^
         --vpn-rotate --vpn-network-lock

REM সব session ব্যবহার করতে (5561টি session আছে):
run.bat --sessions sassion --lanes 500 --threads 150 ^
         --rate-per-ip 1200 --rate-per-session 72 --warmup 40 ^
         --vpn-rotate --vpn-network-lock

REM proxy থাকলে: প্রতি IP আলাদা budget -> linear scale
run.bat --sessions sassion --proxies proxies.txt --lanes 300
```

### 🚀 Measured throughput (live, real Reddit, 2026-11-09)

| Config | Users | Time | **Rate** | Errors |
|---|---|---|---|---|
| 120 lanes · 60 threads · 600/min IP | 192 | 28.6 s | 403/min | **0** |
| 300 lanes · 120 threads · 900/min IP | 944 | 61.3 s | 924/min | **0** |
| **466 lanes · 150 threads · 1200/min IP** | **1132** | **57.4 s** | **1184/min** ✅ | **0** |

**1000+ users/minute goal achieved with ~18% headroom and ZERO errors.**
Session mode = **1 request per user** (no jsc challenge, no age gate).
Details: `PLAN-fast-karma-filter.md`.

| Flag | Default | মানে |
|---|---|---|
| `--sessions <dir>` | – | session folder (multi mode চালু) |
| `--lanes <n>` | 0 (=session সংখ্যা) | lane pool size (client সংখ্যা) |
| `--max-per-session <n>` | 25 | এক session কত user-এর পরে lane rotate করবে |
| `--rate-per-session <n>` | 72 | প্রতি account-এর request/মিনিট |
| `--rate-per-ip <n>` | 600 | প্রতি IP-তে request/মিনিট (safety net) |
| `--burst <n>` | 2 | burst size (10 করবেন না) |
| `--aimd` | on | closed-loop rate control (block দেখলে নিজে থেকেই rate কমায়) |
| `--preflight-sample <n>` | 40 | startup-এ কত session probe করবে |
| `--warmup <n>` | 10 | প্রথম Nটা request ধীর |

### VPN auto-rotation (ExpressVPN) ⭐ NEW

IP rate limit detect হলে script নিজেই VPN rotate করে: **disconnect → 1s gap →
পরের region-এ connect → exit IP verify** → সব worker আবার চালু (কোনো crash না,
progress হারায় না)।

```bat
REM simplest: সব default-ই ঠিক আছে (auto 217 region discovery)
run.bat --sessions sassion --threads 50 --lanes 100

REM শুধু USA server রাখতে + kill switch (real IP leak শূন্য)
run.bat --sessions sassion --lanes 100 --vpn-country usa --vpn-network-lock

REM VPN ছাড়া চালাতে
run.bat --vpn-rotate=false
```

| Flag | Default | মানে |
|---|---|---|
| `--vpn <path>` | ExpressVPN install path | expressvpnctl.exe পথ (`""` = off) |
| `--vpn-rotate` | on | rotation master switch |
| `--vpn-country <text>` | all 217 regions | শুধু matching region রাখে, যেমন `usa` |
| `--vpn-locations <file>` | auto-discover | নিজের region list (একটা per line) |
| `--vpn-gap <s>` | 1 | disconnect → connect gap |
| `--vpn-threshold <n>` | 6 | পরপর কতটা throttle হলে rotate |
| `--vpn-max-rotations <n>` | 30 | run-এর সর্বোচ্চ rotation (0 = unlimited) |
| `--vpn-min-interval <s>` | 30 | দুই rotation-এর মাঝে ন্যূনতম বিরতি |
| `--vpn-connect-timeout <s>` | 45 | Connected state-এর জন্য অপেক্ষা |
| `--vpn-network-lock` | off | kill switch চালু (leak-proof) |
| `--vpn-verify-ip` | on | rotation-এর পর IP বদলেছে কিনা verify |

**কীভাবে কাজ করে:** throttle detector (৬টা পরপর throttle বা শেষ ফলাফলের ৩০%)
fire করলে সব worker park হয় → `expressvpnctl get regions` থেকে পরের region
বাছাই → disconnect → state confirm → 1s gap → connect → `Connected` পর্যন্ত poll
→ api.ipify.org দিয়ে IP বদলেছে verify (না বদলালে পরের region, ৩ বার) →
lane/breaker/session সব reset (নতুন IP = clean slate) → কাজ চালু।
Rotation history দেখুন: `session_usage.txt`-এর `VPN ROTATIONS` অংশ।

**কেন session দরকার:** session cookie ছাড়া Reddit NSFW প্রোফাইলে age-gate দেখায়
(`login_required`)। Session থাকলে age-gate মুছে যায় → NSFW-ও exact karma আসে।

### 🔎 Debug (step by step)

```bat
REM প্রতিটি fetch/solve round, HTTP status, 429 backoff, breaker ও VPN rotation দেখতে:
set KARMA_DEBUG=1
run.bat --sessions sassion --lanes 20 --threads 5
```

এটা normal output না বদলে আলাদা `[debug]` লাইন print করে — তাই result file
একদম Python-compatible থাকে।

### 🔇 Quiet mode (live log বন্ধ)

```bat
run.bat --sessions sassion --lanes 466 --threads 150 --quiet
REM অথবা সরাসরি:
userkarmacheck.exe check -i input.txt -o full_out --sessions sassion ^
  --lanes 466 --threads 150 --rate-per-ip 1200 --quiet
```

`--quiet` দিলে per-user লাইন (`[123/3972] HIT ...`, `Preflight: fetching ...`,
lane/session list) **সব বন্ধ** — শুধু শুরুর ৫-৬ লাইন আর শেষে **RUN REPORT**
দেখাবে। `run_fast.bat`-এ `--quiet` আগে থেকেই দেওয়া আছে।

### 📺 Live Status panel (check.py-এর rich.live panel)

ডিফল্টলি কনসোলে একটা **in-place bordered table** দেখাবে (প্রতি ইউজারে
একই জায়গায় redraw হয়, per-user লাইন থাকে না):

```
╭─ Live Status ─────────────────────────────╮
│ Status                      │ Value        │
├─────────────────────────────┼──────────────┤
│ Total To Check              │ 3972         │
│ Checked                     │ 1184         │
│ Valid                       │ 683          │
│ Invalid (Banned/Suspended)  │ 261          │
│ Failed (Connection/Timeout) │ 0            │
│ Checks per minute           │ 1184         │
╰───────────────────────────────────────────╯
```

Output কোনো ফাইলে redirect করলে panel-এর বদলে প্রতি ৫ সেকেন্ডে একটা সাধারণ
লাইন লেখা হয় (লগ ফাইল পড়ার উপযোগী থাকে)।

### 🧹 Input validation (check.py-এর মতো)

run শুরুর আগেই credential ফিল্টার চলে — ভাঙা লাইনগুলো Reddit-এ পাঠানো হয় না:

```
Total lines in input.txt: 3972
Rejected for invalid usernames: 12
Rejected for short usernames (<6 chars): 3
Rejected for blacklisted values: 1
Rejected for valid usernames but short passwords: 87
Rejected for [NOT_SAVED] markers: 0
Rejected for numeric-only usernames: 4
Proceeding to check 3865 accounts on Reddit...
```

নিয়ম (Python script-এর হুবহু): username regex `^[a-zA-Z0-9_-]{3,20}$`,
username ≥ 6 অক্ষর, password ≥ 8 অক্ষর, `[not_saved]` বাদ, numeric-only বাদ,
`unknown/none/admin` বাদ।

### 🧭 সবচেয়ে দ্রুত চালানোর নিয়ম

1. **`--sessions sassion` সবসময় দিন** — এটাই 1 request/user দেয় (challenge + age-gate
   দুটোই bypass হয়)।
2. `--lanes` = session সংখ্যার সমান (এখন 5561), `--threads` = lanes-এর ~⅓।
3. `--rate-per-ip` বাড়াতে থাকুন (1200/min এখানে clean ছিল) — block দেখলে AIMD
   নিজে থেকেই কমিয়ে দেবে, আর VPN rotation হবে।
4. NSFW user-এর জন্য কিছুই আলাদা করতে হবে না — session-এর `over18` cookie-ই যথেষ্ট।
5. `--vpn-network-lock` দিলে real IP leak হবে না।

**Output:** ৮টা file (Python-এর byte-identical) + `session_usage.txt` (কোন session কী করেছে)

### Commands

```
userkarmacheck              (default) check
userkarmacheck check        check - সব flags
userkarmacheck login        real Chrome-এ login → cookies.json
userkarmacheck sessions     saved cookie sessions validate (browser)
userkarmacheck fetch <user> একটা username
userkarmacheck probe        cookie file health check (valid/dead)
```

### Session validation (browser, cookie injection only)

`sassion/` folder-এ থাকা cookie session files (Netscape / JSON / raw header — যেকোনো
format) **real Chrome**-এ inject করে reddit.com খুলে যাচাই করে:

```
userkarmacheck sessions                  # browser window দেখাবে
userkarmacheck sessions --headless       # background
userkarmacheck sessions --dir myfolder
```

- **কোনো user:pass submit হয় না** — শুধু cookie injection
- প্রতিটা file-এর জন্য: `VALID` (account + karma + over18) / `DEAD` / `BANNED` / `UNKNOWN`
- রিপোর্ট: `sassion/sassion_report.txt` + প্রতিটা session-এর `<name>.status.txt`
- ফাইলের header-এ `Username:` / `Suspended:` / `Karma:` থাকলে সেটাও পড়া হয়

---

## English

**What it does:** checks Reddit usernames from `input.txt` and saves them into karma
range files. Same output format as the Python project — drop-in compatible.

**Requirements:** Go 1.22+ (to build), Google Chrome (for login).

### Quick start

1. `login.bat` → real Chrome opens → log in manually → script verifies the session,
   saves `cookies.json` / `cookie_string.txt` / `login_status.txt` → browser closes.
   (Needed for NSFW/mature profiles.)
2. `run.bat` → checks every username in `input.txt`.

### How it works

- **Source ladder (per user)** — কোনো user-কে ছাড়া দেওয়ার আগে ৫টা source
  পরীক্ষা করে:
  ```
  1. JSON + session   ← সবচেয়ে দ্রুত, exact field, NSFW ✅
  2. HTML + session   ← jsc solver
  3. JSON anonymous
  4. HTML anonymous + jsc
  5. Real Chrome      ← শেষ সূত্র (100% authentic)
  ```
  `throttled` হলে → IP budget অপেক্ষা করে **একই source** আবার; `needs_session`
  হলে → **পরের source**-এ সঙ্গে সঙ্গে (কোনো wait নয়)।
- **Chrome TLS fingerprint** — `tls-client` (uTLS-based) with the Chrome_133
  profile. Plain Go TLS gets hard-blocked by Reddit (verified); HTTP/2 is
  silently hung by Reddit, so the client speaks HTTP/1.1 over the Chrome TLS
  hello with a full Chrome header set (sec-ch-ua / sec-fetch-* / Accept-Encoding).
- **JS-challenge solver** — Reddit's 2026 anti-bot gate solved over plain HTTP
  (no browser needed) in 2-4 rounds, with retries for transient 403/429.
- **Per-IP rate limiting** — shared token bucket (60/min default, burst 2),
  429 backoff honoring `Retry-After`, circuit breaker (10 blocks → 5 min
  cooldown → auto-recover), adaptive concurrency (error rate > 30% → fewer
  workers). The budget is shared by every lane on the same IP (measured:
  Reddit limits cookie sessions per IP, not per account).
- **Session management** — cookie store, `/api/v1/me` health check before the run,
  mid-run expiry detection → clean stop with "run login" message.
- **Browser login** — rod drives the *installed* Chrome with a unique profile +
  randomized UA, human-like flow (homepage → wait → hover → click "Log in").
- **Output parity** — byte-identical to the Python project (same files, same
  lines, same CRLF endings, same UTF-8).

### Troubleshooting

| Symptom | Fix |
|---|---|
| `login_required` for NSFW users | run `login.bat` first |
| `Session check FAILED` | cookies expired → run `login.bat` again |
| `blocked` errors | IP throttled → wait a few minutes, or use `--proxies` |
| Nothing happens on `run.bat` | `input.txt` missing/empty in this folder |

### Build

```bat
go build -o userkarmacheck.exe .
```
