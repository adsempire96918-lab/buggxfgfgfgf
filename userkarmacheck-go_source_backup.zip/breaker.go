// Package main — per-IP circuit breaker.
// N consecutive blocked/unauthorized responses open the circuit; after a
// cooldown a single half-open probe decides recovery.
package main

import (
	"context"
	"sync"
	"time"
)

type BreakerState int

const (
	StateClosed BreakerState = iota
	StateOpen
	StateHalfOpen
)

// CircuitBreaker opens after maxConsecutive block-class failures.
type CircuitBreaker struct {
	mu             sync.Mutex
	state          BreakerState
	consecutive    int
	maxConsecutive int
	cooldown       time.Duration
	openedAt       time.Time
	probing        bool
}

func NewCircuitBreaker(maxConsecutive int, cooldown time.Duration) *CircuitBreaker {
	if maxConsecutive <= 0 {
		maxConsecutive = 10
	}
	if cooldown <= 0 {
		cooldown = 15 * time.Minute
	}
	return &CircuitBreaker{state: StateClosed, maxConsecutive: maxConsecutive, cooldown: cooldown}
}

// Allow blocks while the circuit is open (up to ctx). A half-open probe
// lets exactly one request through.
func (c *CircuitBreaker) Allow(ctx context.Context) error {
	for {
		c.mu.Lock()
		switch c.state {
		case StateClosed:
			c.mu.Unlock()
			return nil
		case StateOpen:
			if time.Since(c.openedAt) >= c.cooldown {
				c.state = StateHalfOpen
				c.probing = true
				c.mu.Unlock()
				return nil
			}
			wait := c.cooldown - time.Since(c.openedAt)
			c.mu.Unlock()
			timer := time.NewTimer(wait)
			select {
			case <-ctx.Done():
				timer.Stop()
				return ctx.Err()
			case <-timer.C:
			}
		case StateHalfOpen:
			if !c.probing {
				c.probing = true
				c.mu.Unlock()
				return nil
			}
			c.mu.Unlock()
			// another probe is in flight; wait a beat and re-check
			time.Sleep(200 * time.Millisecond)
		}
	}
}

// Report records one request outcome. blocked = 401/403 block-class.
func (c *CircuitBreaker) Report(blocked bool) {
	c.mu.Lock()
	defer c.mu.Unlock()
	switch c.state {
	case StateHalfOpen:
		c.probing = false
		if blocked {
			c.state = StateOpen
			c.openedAt = time.Now()
		} else {
			c.state = StateClosed
			c.consecutive = 0
		}
	case StateOpen:
		// stay open; Allow() re-evaluates the cooldown
	case StateClosed:
		if blocked {
			c.consecutive++
			if c.consecutive >= c.maxConsecutive {
				c.state = StateOpen
				c.openedAt = time.Now()
				debugf("breaker: OPEN after %d consecutive blocks (cooldown %s)", c.consecutive, c.cooldown)
			}
		} else {
			c.consecutive = 0
		}
	}
}

// State returns the current breaker state.
func (c *CircuitBreaker) State() BreakerState {
	c.mu.Lock()
	defer c.mu.Unlock()
	return c.state
}

// IsBlocked reports whether requests would wait right now.
func (c *CircuitBreaker) IsBlocked() bool {
	c.mu.Lock()
	defer c.mu.Unlock()
	return c.state == StateOpen && time.Since(c.openedAt) < c.cooldown
}

// Reset forces the breaker closed and clears the consecutive counter. Used
// after a VPN IP rotation: the blocks belonged to the old exit IP, so the
// fresh IP starts with a clean breaker.
func (c *CircuitBreaker) Reset() {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.state = StateClosed
	c.consecutive = 0
	c.probing = false
}
